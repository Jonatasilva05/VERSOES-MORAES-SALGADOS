# Versão de alto contraste

Exemplo de site com versão de alto contraste